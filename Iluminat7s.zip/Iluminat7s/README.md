Iluminat7s cryptocurrency discretion and privacy.

Principal cryptocurrency Iluminat7s; "Solidarity and economy for all."

First order: Iluminat7s is not immune to the Law of Fives, nor the Seventeen, nor the Twentythree enigmata.

Second order: Offering of Iluminat7s to Eris may bring illumination, offer with caution or donte. It may also cause flushness, shortness of breath, cold fingers, pins and needles in the feet and hands, and gas.

Third order: Of each Iluminat7s (and there are twenty-three), one one thousandth is a single Ilums. Proper offering shall result in bestowation of milliChao which are tiny, very tiny indeed. Improper offering results in nil.

Seventh order: The true gods are closer, you do not proclaim to a god who gives you nothing.

Eighth Order: To see, to hear and to be silent, finds happiness.

See the fnords.
